<?php
$review=$_POST['review'];
echo  "$review";

?>