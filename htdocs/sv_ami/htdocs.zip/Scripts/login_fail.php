<?php
echo  "Contul se afla deja in baza de date!";
?>