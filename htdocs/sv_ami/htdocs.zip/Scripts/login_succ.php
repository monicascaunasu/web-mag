<?php
echo  "Contul a fost creat cu succes !!!";
?>